"""Higher-level workflow utilities used by the FastAPI app."""
from services.orchestrator import run_for_counterparty, start_orchestrator
from services.feedback_loop import store_correction, get_corrections

async def start_workflow():
    # Start background tasks, schedulers, etc. For prototype, just initialize.
    await start_orchestrator()
    return True

async def get_risk_profile(counterparty_id: str):
    profile = await run_for_counterparty(counterparty_id)
    return profile

async def submit_correction(counterparty_id: str, correction: dict):
    return store_correction(counterparty_id, correction)
