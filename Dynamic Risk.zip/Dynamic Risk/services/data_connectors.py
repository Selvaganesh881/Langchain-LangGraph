"""Mocked data connectors module. Replace with real connectors."""
async def fetch_internal_loan_feed(counterparty_id: str):
    return {'loans': 500}

async def fetch_exposure_store(counterparty_id: str):
    return {'derivatives': 200}

async def fetch_collateral_store(counterparty_id: str):
    return {'collateral_value': 300}

async def fetch_sec_filings(counterparty_id: str):
    return ['10-Q: delayed filing']

async def fetch_news(counterparty_id: str):
    return ['Analyst: weaker guidance', 'Local press: management change']

async def fetch_ratings(counterparty_id: str):
    return {'rating': 'BBB', 'outlook': 'negative'}
