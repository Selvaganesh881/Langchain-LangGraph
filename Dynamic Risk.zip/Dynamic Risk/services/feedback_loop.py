"""Prototype feedback loop: store analyst adjustments locally (mock)."""
import os, json
STORAGE = '/mnt/data/dynamic_risk_feedback.json'

def store_correction(counterparty_id: str, correction: dict):
    data = {}
    if os.path.exists(STORAGE):
        with open(STORAGE,'r') as f:
            try:
                data = json.load(f)
            except:
                data = {}
    data.setdefault(counterparty_id, []).append({'correction': correction})
    with open(STORAGE,'w') as f:
        json.dump(data, f, indent=2)
    return True

def get_corrections(counterparty_id: str):
    if os.path.exists(STORAGE):
        with open(STORAGE,'r') as f:
            data = json.load(f)
            return data.get(counterparty_id, [])
    return []
