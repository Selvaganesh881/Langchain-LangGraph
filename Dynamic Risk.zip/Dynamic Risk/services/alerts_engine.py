"""Simple alerting rules for prototype."""
def evaluate_alerts(risk_profile: dict) -> list:
    alerts = []
    sc = risk_profile.get('dynamic_score', 1.0)
    qual = risk_profile.get('qual', {})
    if sc < 0.3:
        alerts.append('HIGH RISK: dynamic score below 0.3')
    sentiment = qual.get('sentiment_score')
    if sentiment is not None and sentiment < 0:
        alerts.append('NEGATIVE_SENTIMENT: negative media or filings detected')
    # Add rating-based alerts if available
    # ...
    return alerts
