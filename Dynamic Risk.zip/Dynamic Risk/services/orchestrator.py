"""Orchestrator coordinating agents synchronously (simple version)."""
import asyncio
from agents.ingestion_agent import ingest
from agents.quant_agent import compute_metrics
from agents.researcher_agent import analyze_texts
from agents.synthesis_agent import synthesize
from agents.memo_gen_agent import generate_memo
from services.alerts_engine import evaluate_alerts

async def run_for_counterparty(counterparty_id: str) -> dict:
    data = await ingest(counterparty_id)
    quant = compute_metrics(data['structured_data'])
    qual = analyze_texts(data['unstructured_texts'])
    profile = synthesize(counterparty_id, quant, qual)
    memo = generate_memo(profile)
    profile['memo'] = memo
    profile['alerts'] = evaluate_alerts(profile)
    return profile

async def start_orchestrator():
    # For a real app this would schedule regular runs and watchlists
    return True
