"""Memo generation agent: convert risk profile to human-readable memo."""
from prompts import MEMO_GEN_PROMPT
from llm_utils import call_gemini
import json

def generate_memo(risk_profile: dict) -> str:
    prompt = MEMO_GEN_PROMPT.format(risk_profile_json=json.dumps(risk_profile))
    resp = call_gemini(prompt, model='gemini-2.5-pro')
    # For prototype, create a simple formatted memo
    memo = []
    memo.append(f"Executive Summary: Dynamic score {risk_profile['dynamic_score']} for {risk_profile['counterparty_id']}")
    memo.append("\nKey Metrics:")
    for k,v in risk_profile['quant'].items():
        memo.append(f" - {k}: {v}")
    memo.append("\nRecent Events:")
    for e in risk_profile['qual']['key_events']:
        memo.append(f" - {e}")
    memo.append("\nRecommended Actions:")
    memo.append(" - Review exposures; consider hedging; monitor rating agencies.")
    return '\n'.join(memo)
