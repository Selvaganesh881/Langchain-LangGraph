"""Risk synthesis agent: combine quant + qual into dynamic score."""
from prompts import SYNTHESIS_AGENT_PROMPT
from llm_utils import call_gemini
from schemas import RiskProfile
from datetime import datetime
import json

def synthesize(counterparty_id: str, quant, qual) -> dict:
    # Build a simple heuristic score for prototype:
    # Start at 0.5, subtract for high leverage, negative sentiment, low liquidity
    score = 0.5
    if quant.leverage:
        if quant.leverage > 6: score -= 0.2
        elif quant.leverage > 3: score -= 0.1
    if quant.liquidity_ratio is not None and quant.liquidity_ratio < 0.2:
        score -= 0.15
    if qual.sentiment_score is not None:
        score -= (1 - qual.sentiment_score) * 0.2
    score = max(0.0, min(1.0, score))
    profile = {
        'counterparty_id': counterparty_id,
        'timestamp': datetime.utcnow().isoformat() + 'Z',
        'dynamic_score': round(score,3),
        'quant': quant.dict(),
        'qual': qual.dict(),
        'memo': None,
        'alerts': []
    }
    return profile
