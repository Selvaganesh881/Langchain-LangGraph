"""Researcher agent: analyze unstructured texts (mocked LLM-based summaries)."""
from prompts import RESEARCHER_AGENT_PROMPT
from llm_utils import call_gemini
from schemas import QualitativeInsights

def analyze_texts(unstructured_texts: list) -> QualitativeInsights:
    prompt = RESEARCHER_AGENT_PROMPT.format(unstructured_list=unstructured_texts)
    resp = call_gemini(prompt, model='gemini-2.5-flash')
    # Mock: simple heuristics
    negative = sum(1 for t in unstructured_texts if 'delay' in t.lower() or 'weaker' in t.lower())
    sentiment = max(-1.0, min(1.0, 1.0 - negative*0.6))
    key_events = [t for t in unstructured_texts]
    return QualitativeInsights(
        sentiment_score=round(sentiment,3),
        key_events=key_events,
        governance_flags=[],
        raw_excerpts=unstructured_texts
    )
