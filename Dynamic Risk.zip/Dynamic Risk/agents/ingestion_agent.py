"""Data ingestion agent - mocked connectors for prototype."""
import asyncio
from llm_utils import call_gemini
from prompts import DATA_INGEST_PROMPT
import json

async def ingest(counterparty_id: str) -> dict:
    prompt = DATA_INGEST_PROMPT.format(counterparty_id=counterparty_id)
    # Real implementation would call connectors and enrich data
    resp = call_gemini(prompt, model='gemini-2.5-flash')
    # Mocked structured/unstructured split
    return {
        'structured_data': {
            'financials': {
                'debt': 1000,
                'ebitda': 120,
                'cash': 200
            },
            'exposures': {
                'loans': 500,
                'derivatives': 200
            }
        },
        'unstructured_texts': [
            'Company announced a delayed filing.',
            'Analyst note: modestly weaker guidance next quarter.',
        ],
        'meta': resp
    }
