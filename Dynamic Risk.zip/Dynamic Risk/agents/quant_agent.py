"""Quantitative agent: computes financial metrics from structured data."""
from schemas import QuantMetrics
from prompts import QUANT_AGENT_PROMPT
from llm_utils import call_gemini
import math

def compute_metrics(structured_data: dict) -> QuantMetrics:
    fin = structured_data.get('financials', {})
    exposures = structured_data.get('exposures', {})
    debt = fin.get('debt') or 0
    ebitda = fin.get('ebitda') or 1
    cash = fin.get('cash') or 0
    loans = exposures.get('loans') or 0
    derivatives = exposures.get('derivatives') or 0
    leverage = debt / ebitda if ebitda else None
    liquidity_ratio = (cash / debt) if debt else None
    exposure = loans + derivatives
    concentration = (loans / exposure) if exposure else None
    return QuantMetrics(
        leverage=round(leverage, 3) if leverage is not None else None,
        liquidity_ratio=round(liquidity_ratio, 3) if liquidity_ratio is not None else None,
        exposure=round(exposure, 3),
        concentration=round(concentration, 3) if concentration is not None else None,
        other={}
    )
