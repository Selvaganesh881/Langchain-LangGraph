"""FastAPI entrypoint for Dynamic Risk prototype."""
import uvicorn
from fastapi import FastAPI
from config import settings
from services.workflow import start_workflow, get_risk_profile

app = FastAPI(title='Dynamic Risk - Agentic Prototype')

@app.on_event('startup')
async def startup_event():
    # Optionally start background watcher / orchestrator
    app.state.workflow = await start_workflow()

@app.get('/health')
async def health():
    return {'status': 'ok'}

@app.get('/risk/{counterparty_id}')
async def risk(counterparty_id: str):
    """Return the latest dynamic risk profile for a counterparty."""
    profile = await get_risk_profile(counterparty_id)
    return profile

if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=8000, reload=True)
