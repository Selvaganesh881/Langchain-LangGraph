from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class QuantMetrics(BaseModel):
    leverage: Optional[float]
    liquidity_ratio: Optional[float]
    exposure: Optional[float]
    concentration: Optional[float]
    other: Dict[str, Any] = {}

class QualitativeInsights(BaseModel):
    sentiment_score: Optional[float]
    key_events: List[str] = []
    governance_flags: List[str] = []
    raw_excerpts: List[str] = []

class RiskProfile(BaseModel):
    counterparty_id: str
    timestamp: str
    dynamic_score: float = Field(..., ge=0.0, le=1.0)
    quant: QuantMetrics
    qual: QualitativeInsights
    memo: Optional[str] = None
    alerts: List[str] = []
