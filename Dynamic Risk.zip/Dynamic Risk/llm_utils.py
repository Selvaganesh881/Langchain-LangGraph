from langchain_google_genai import ChatGoogleGenerativeAI
from config import settings

# Create a single global client
gemini_llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    google_api_key=settings.google_api_key,
    temperature=0.3,
)

async def call_gemini(prompt: str, model: str = "gemini-2.5-flash"):
    """Unified LLM call using LangChain."""
    llm = ChatGoogleGenerativeAI(
        model=model,
        google_api_key=settings.google_api_key,
        temperature=0.3,
    )
    
    result = llm.invoke(prompt)
    return result.content
